package com.example.jdbc;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class StoredProcExample {

    public static void main(String[] args) {
        try {
            // Load the database properties
            Properties props = loadPropertiesFile("db.properties");

            // Establish the database connection
            Connection conn = DriverManager.getConnection(props.getProperty("url"), props.getProperty("username"), props.getProperty("password"));

            // Create a CallableStatement for the stored procedure
            CallableStatement cstmt = conn.prepareCall("{call insert_employee(?, ?)}");

            // Set the input parameters
            cstmt.setString(1, "John Doe");
            cstmt.setInt(2, 30);

            // Execute the stored procedure
            cstmt.execute();

            System.out.println("Stored procedure executed successfully.");

            // Retrieve the output parameter
            int employeeId = cstmt.getInt(1);
            System.out.println("Inserted employee ID: " + employeeId);

            // Close the statement and connection
            cstmt.close();
            conn.close();
        } catch (SQLException e) {
            // Handle any database errors
            e.printStackTrace();
        }
    }

    private static Properties loadPropertiesFile(String filename) {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(filename)) {
            props.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return props;
    }
}
