package com.yourcompany;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseOperations {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Bh@rathreddy1234";

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;

        try {
            // Step 1: Connect to the MySQL server
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            System.out.println("Connected to the MySQL server");

            // Step 2: Create a new database
            String createDatabaseQuery = "CREATE DATABASE mydatabase";
            statement = connection.createStatement();
            statement.executeUpdate(createDatabaseQuery);
            System.out.println("Database created successfully");

            // Step 3: Select the newly created database
            String useDatabaseQuery = "USE mydatabase";
            statement.executeUpdate(useDatabaseQuery);
            System.out.println("Using database: mydatabase");

            // Step 4: Drop the database
            String dropDatabaseQuery = "DROP DATABASE mydatabase";
            statement.executeUpdate(dropDatabaseQuery);
            System.out.println("Database dropped successfully");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Step 5: Close the resources
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
